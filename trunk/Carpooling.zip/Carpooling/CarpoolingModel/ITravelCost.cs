﻿using System;
namespace CarpoolingModel
{
    interface ITravelCost
    {
        float calculateCosts(Group group);
    }
}

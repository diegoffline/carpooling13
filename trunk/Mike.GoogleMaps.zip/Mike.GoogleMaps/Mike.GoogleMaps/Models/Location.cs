namespace Mike.GoogleMaps.Models
{
    public class Location
    {
        public string Name { get; set; }
        public LatLng LatLng { get; set; }
        public string Image { get; set; }
    }
}
﻿using System.Web.Mvc;
using Mike.GoogleMaps.Repositories;

namespace Mike.GoogleMaps.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Home Page";
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            ViewData["Title"] = "About Page";

            return View();
        }

        public ActionResult Map()
        {
            var mapRepository = new MapRepository();
            var map = mapRepository.GetById(1);
            return Json(map);
        }
    }
}

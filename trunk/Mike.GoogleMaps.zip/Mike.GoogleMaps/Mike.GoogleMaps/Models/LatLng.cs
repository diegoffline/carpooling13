namespace Mike.GoogleMaps.Models
{
    public class LatLng
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}